import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const {WorkflowRuntime}=await import(pathToFileURL(join(root,'packages/edge-worker/dist/factory/WorkflowRuntime.js')));
const {validateWorkflows}=await import(pathToFileURL(join(root,'packages/edge-worker/dist/factory/Workflow.js')));
const {defaultWorkflows}=await import(pathToFileURL(join(root,'packages/edge-worker/dist/factory/defaultWorkflows.js')));
const agent=(id,x={})=>({id,name:id,type:'agent',prompt:'Controlled review fixture',...x});
for (const mode of ['foreach','mapped-call']) {
 const home=mkdtempSync(join(tmpdir(),'foreach-review-'));
 const calls=[];
 const runtime=new WorkflowRuntime(home,{agent:async c=>{calls.push(c.stepKey);return c.stepKey==='skipped'?{approved:true,authority:'outer-only'}:{routed:true};},tool:async()=>{throw Error('unexpected tool')},script:async()=>{throw Error('unexpected script')}});
 try {
  const body=[agent('route',{next:'end'}),agent('skipped')];
  const definitions=validateWorkflows([...defaultWorkflows,...(mode==='mapped-call'?[{id:'child-fixture',name:'Child',stepConfigVersion:'step-config-v1',steps:body}]:[]),{id:'review-fixture',name:'Review',stepConfigVersion:'step-config-v1',steps:[agent('skipped'),mode==='foreach'?{id:'each',name:'Each',type:'foreach',items:{values:[{id:'a'}]},body}:{id:'call',name:'Call',type:'workflow',workflow:'child-fixture',inputMapping:{}},{id:'verify',name:'Verify child approval',type:'check',reads:{batch:mode==='foreach'?'each':'call'},check:{results:{childApproved:{path:mode==='foreach'?'/inputs/batch/results/a/skipped/approved':'/inputs/batch/outputs/skipped/approved',equals:true}}}}]}]);
  runtime.updateWorkflows(definitions);
  const workflow=definitions.at(-1);
  const run=runtime.create({title:'Review controlled probe',repositoryId:'fixture',workspace:home,input:'fixture',workflow,triggerOrigin:{type:'manual',workflowId:workflow.id,at:new Date().toISOString()}});
  await runtime.launch(run);
  console.log(JSON.stringify({mode,calls,status:runtime.get(run.id).status,outputs:runtime.get(run.id).outputs,history:runtime.get(run.id).history.map(h=>h.step)}));
 } finally {await runtime.shutdown();rmSync(home,{recursive:true,force:true});}
}
