import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
const {prepareForeach}=await import(pathToFileURL(join(process.cwd(),'packages/edge-worker/src/factory/Foreach.ts')));
let calls=0;
const item=Object.defineProperty({id:'a'},'toJSON',{get(){calls++;return ()=>({id:'changed'});}});
for(const [name,step,scope] of [
 ['inline-hidden-toJSON',{items:{values:[item]}},{outputs:{}}],
 ['output-hidden-toJSON',{items:{from:'/source/items'}},{outputs:{source:{items:[item]}}}],
 ['inherited-values',{items:Object.create({get values(){calls++;return [{id:'a'}]}})},{outputs:{}}]
]){calls=0;try{console.log(JSON.stringify({name,result:prepareForeach(step,scope),getterCalls:calls}));}catch(e){console.log(JSON.stringify({name,error:e.message,getterCalls:calls}));}}
const sparse=new Array(1);sparse.foo={id:'a'};
const accepted=prepareForeach({items:{values:sparse}},{outputs:{}});
console.log(JSON.stringify({name:'sparse-extra-property',length:accepted.items.length,hasIndex0:Object.hasOwn(accepted.items,0)}));
