import assert from 'node:assert/strict';
import {prepareForeach} from '/Users/jappy/.t3/worktrees/bobs-factory/taskbot-138-foreach/packages/edge-worker/src/factory/Foreach.ts';
let calls=0;
const item=Object.defineProperty({id:'a'},'toJSON',{get(){calls++;return ()=>({id:'changed'});}});
for(const [name,step,scope] of [
 ['inline-hidden-toJSON',{items:{values:[item]}},{outputs:{}}],
 ['output-hidden-toJSON',{items:{from:'/source/items'}},{outputs:{source:{items:[item]}}}],
 ['inherited-values',{items:Object.create({get values(){calls++;return [{id:'a'}]}})},{outputs:{}}]
]){calls=0;assert.throws(()=>prepareForeach(step,scope));assert.equal(calls,0);console.log(JSON.stringify({name,rejected:true,getterCalls:calls}));}
const sparse=new Array(1);sparse.foo={id:'a'};
assert.throws(()=>prepareForeach({items:{values:sparse}},{outputs:{}}));
console.log(JSON.stringify({name:'sparse-extra-property',rejected:true}));
assert.deepEqual(prepareForeach({items:{values:[{id:'valid',payload:[1,null]}]}},{outputs:{}}).items.map(x=>x.id),['valid']);
console.log(JSON.stringify({validDataPreserved:true,result:'PASS'}));
