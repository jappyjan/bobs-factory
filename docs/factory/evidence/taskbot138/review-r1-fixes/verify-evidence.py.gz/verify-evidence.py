import gzip,hashlib,json,pathlib,re,struct,subprocess
root=pathlib.Path('/Users/jappy/.t3/worktrees/bobs-factory/taskbot-138-foreach');p=root/'docs/factory/evidence/taskbot138/review-r1-fixes';idx=json.loads((p/'validation-index.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True).strip()
for kind in ['logs','rawJson','probes']:
 for rec in idx[kind]:
  data=(p/rec['retained']).read_bytes();raw=gzip.decompress(data);assert sha(raw)==rec['sha256'] and sha(data)==rec['gzipSha256']
  if kind=='rawJson':assert json.loads(raw)==json.loads((p/pathlib.Path(rec['retained']).name.removesuffix('.gz')).read_text())
for rec in idx['screenshots']:
 data=(p/rec['retained']).read_bytes();assert sha(data)==rec['sha256'];assert struct.unpack('>II',data[16:24])==(rec['dimensions']['width'],rec['dimensions']['height'])
u=json.loads((p/'ui-identity.json').read_text())
for path,digest in u['source'].items():assert sha((root/path).read_bytes())==digest,path
for path,digest in u['backend'].items():assert sha((root/'packages/edge-worker/dist/factory'/path).read_bytes())==digest,path
web=root/'packages/edge-worker/dist/factory/web';current=json.loads((web/'current.json').read_text());assert current['directory']=='build-'+u['build']
for rec in u['assets']:
 path=web/current['directory']/('index.html' if rec['path']=='/' else rec['path'].lstrip('/'));assert sha(path.read_bytes())==rec['sha256']
build=hashlib.sha256()
for name in ['core','mcp-tools','edge-worker']:
 dist=root/'packages'/name/'dist'
 for file in sorted(str(x.relative_to(dist)) for x in dist.rglob('*.js')):build.update(f'{name}/{file}'.encode()+b'\0'+(dist/file).read_bytes()+b'\0')
build.update(b'apps/f1/dist/src/MockAgentRunner.js\0'+(root/'apps/f1/dist/src/MockAgentRunner.js').read_bytes()+b'\0')
for name,driver in [('original','taskbot138-foreach.mjs'),('ownership','taskbot138-foreach-ownership.mjs')]:
 f=json.loads((p/f'f1-{name}-results-index.json').read_text());assert f['result']=='PASS' and f['buildSha256']==build.hexdigest() and sha((root/'apps/f1/test-drives/assets'/driver).read_bytes())==f['driverSha256']
n=json.loads((p/'native-results.json').read_text());assert n['result']=='PASS' and sha(pathlib.Path(n['binary']).read_bytes())==n['binarySha256'] and sha((root/'docs/factory/evidence/taskbot138/native-foreach-smoke.py').read_bytes())==n['driverSha256'];assert n['startupRuntime']==n['restartRuntime'] and n['startupRuntime']['runtime']['commit']==idx['source'] and n['startupRuntime']['build']==u['build']
for doc in [p/'README.md',p/'ui.md',root/'apps/f1/test-drives/2026-10-22-generic-foreach-review-fixes.md']:
 for link in re.findall(r'\]\(([^)]+)\)',doc.read_text()):
  if not re.match(r'https?://|#',link):assert (doc.parent/link.split('#')[0]).exists(),(doc,link)
allowed=['docs/factory/foreach.md','docs/factory/evidence/taskbot138/review-r1-fixes/','apps/f1/test-drives/2026-10-22-generic-foreach-review-fixes.md']
paths=git('diff','--name-only','19258b1427711693a25dda416a9ac6f231f2f8cc').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
assert all(any(f==a or f.startswith(a) for a in allowed) for f in paths),paths
assert git('diff','7d4d9bf7181d213a0f233fca33f6b7cefa20d10b','--','docs/factory/evidence/taskbot138',':!docs/factory/evidence/taskbot138/review-r1-fixes')==''
print(json.dumps({'result':'PASS','logs':len(idx['logs']),'rawJson':len(idx['rawJson']),'probes':len(idx['probes']),'pngs':len(idx['screenshots']),'uiSource':len(u['source']),'backend':len(u['backend']),'assets':len(u['assets']),'builtJsSha256':build.hexdigest(),'nativeSha256':n['binarySha256'],'postFreezeAllowlist':allowed,'originalEvidenceUnchanged':True}))
